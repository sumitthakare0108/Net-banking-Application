package com.netbanking.JPAaccountadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpAaccountadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpAaccountadminApplication.class, args);
		System.out.println("running............");
	}

}
