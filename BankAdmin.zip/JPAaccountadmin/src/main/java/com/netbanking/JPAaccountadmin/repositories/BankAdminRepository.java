package com.netbanking.JPAaccountadmin.repositories;

import com.netbanking.JPAaccountadmin.entities.BankAdmin;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public interface BankAdminRepository extends JpaRepository<BankAdmin,String>{
    // BankAdmin findByUserid(String usreid,String pswd);

    @Modifying
    @Transactional
    @Query("select * from bankadmin where userid =:uid and pswd =:psw")
    void loginAccountToAdmin(String uid,String psw);
}
