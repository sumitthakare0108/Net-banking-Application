package com.netbanking.JPAaccountadmin.Services;

import com.netbanking.JPAaccountadmin.repositories.BankAdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountServices {

    @Autowired
    BankAdminRepository bankRepo;

    public String loginAccount(String userid,String pswd){
        String status="";
        try{
            bankRepo.loginAccountToAdmin(userid,pswd);
            status = "index.jsp";
        } catch (Exception e) {
            status="fail.jsp";
        }
        return status;
    }
}
