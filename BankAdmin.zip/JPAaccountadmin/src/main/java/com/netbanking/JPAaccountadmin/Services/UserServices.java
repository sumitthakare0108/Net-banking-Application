package com.netbanking.JPAaccountadmin.Services;

import com.netbanking.JPAaccountadmin.entities.Account;
import com.netbanking.JPAaccountadmin.repositories.AccountRepository;
//import com.netbanking.JPAaccountadmin.repositories.BankAdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserServices {



    @Autowired
    AccountRepository accRepo;

    public String insertNewAccount(Account obj){
        String status="";
        try{
            accRepo.save(obj);
            status="success";
        }
        catch (Exception e){
            status="Failed";
            System.out.println(e.getMessage());
        }
        return status;
    }

    public List<Account> getAllAccounts(){
        List<Account> lst = accRepo.findAll();
        return  lst;
    }

    public Account searchAccountData(int accno){
       Account obj = accRepo.findByAccno(accno);
        if (obj==null){
            obj= new Account();
            obj.setAccno(accno);
            obj.setAccnm("Not Found");
            obj.setAcctype("Not Found");
            obj.setBalance(0);
        }
        return obj;
    }

    public String updateAccount(int accno,float amount,String trtype){
        String status= "";
        Account obj = accRepo.findByAccno(accno);
        if (trtype.equals("deposit")){
            obj.setBalance(obj.getBalance()+amount);
        }else {
            obj.setBalance(obj.getBalance()-amount);
        }
        accRepo.save(obj);
        status="success";
        return status;
    }

  public String trasferAmount(int fno,int tno,float amt,String det)
  {
      String status="";
      try{
          accRepo.transferMoney(fno,tno,amt,det);
          status="Success";
      } catch (Exception e) {
          status="Failed";
      }
      return status;
  }

  public String deleteAccount(int accno){
        String status= "";
        Account obj = accRepo.findByAccno(accno);
        if (obj !=null) {
            System.out.println(obj.getAccnm());
            accRepo.delete(obj);
            status = "Success";
        }else {
            status="Failed";
        }
        return status;
  }

  public String deductAmount(String type,float amount){
        accRepo.deductAmountFormAccounts(type,amount);
        return "Success";
  }

}
