package com.netbanking.JPAaccountadmin;

import com.netbanking.JPAaccountadmin.Services.AccountServices;
import com.netbanking.JPAaccountadmin.Services.UserServices;
import com.netbanking.JPAaccountadmin.entities.Account;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@Controller
public class JPAController {
    @Autowired
    UserServices us;

    @Autowired
    AccountServices ac;

    @GetMapping("/")
    public String index(){
        return "home.jsp";
    }

    @PostMapping("/login")
    public String login(String userid,String password,Model m){
        System.out.println(userid);
        System.out.println(password);
        String status=ac.loginAccount(userid,password);
        return status;
    }

    @GetMapping("/newacc")
    public String newAccount(){
        return "newAccount.jsp";
    }

    @PostMapping("/addacc")
    public String addAccount(Account obj, Model m){
        String Status = us.insertNewAccount(obj);
        m.addAttribute("status",Status);
        return "TransactionStatus.jsp";
    }
    @GetMapping("/accrepo")
    public String accReport(Model m){
        List<Account> acclist=us.getAllAccounts();
        m.addAttribute("list",acclist);
        return "AccountReport.jsp";
    }

    @PostMapping("/searchaccno")
    public String searchAccno(int accno,Model m){
        Account obj = us.searchAccountData(accno);

        System.out.println(obj.getAccnm());
        m.addAttribute("acc",obj);
        return "SearchAccResult.jsp";
    }

    @GetMapping("/deposit")
    public String depsitAccount(){
        return "DepositFrom.jsp";
    }
    @GetMapping("/withdraw")
    public String withdrawAccount(){
        return "WithdrawFrom.jsp";
    }

    @PostMapping("/acctransact")
    public String accTransact(int accno,float amount,String trtype,Model m){
        String status = us.updateAccount(accno,amount,trtype);
        m.addAttribute("status",status);
        return "TransactionStatus.jsp";
    }

    @GetMapping("/delete")
    public String deleteAccount(){
        return "DeleteFrom.jsp";
    }

    @GetMapping("/transfer")
    public String transfer(){
        return "TransferForm.jsp";
    }
    @PostMapping("/amount")
    public String amount(int fromamount ,int toaccount,float amount,String purpose,Model m){
        String status="";
        status=us.trasferAmount(fromamount,toaccount,amount,purpose);
        m.addAttribute("status",status);
        return status;
    }

    @PostMapping("/delacc")
    public String delAccount(int accno,Model m){
        String status="";
        status = us.deleteAccount(accno) ;
        m.addAttribute("status",status);
        return "TransactionStatus.jsp";
    }
//
//    @GetMapping()
//    public String login(){
//        return "login.jsp";
//    }

    @GetMapping("/deduct")
    public String deduct(){
        return "DeductFrom.jsp";
    }

    @PostMapping("/dedamt")
    public String dedAmount(String type,float amount,Model m){
        String Status= us.deductAmount(type,amount);
        m.addAttribute("status",Status);
        return "TransactionStatus.jsp";
    }

}
